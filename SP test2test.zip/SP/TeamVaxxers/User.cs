﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamVaxxers
{
    internal class User
    {
        public string UserName = "";
        public string Password = "";
    }
}
