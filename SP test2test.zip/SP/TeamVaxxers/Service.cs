﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamVaxxers
{
    public class Population
    {
        public int K { get; set; }
        public Individual[] individuals { get; set; }

    }
    public class Indi
    {
        // public Individual[] individuals { get; set; }
        public InNeighbor[] In { get; set; }
        public int[] Out { get; set; }
        public double lat { get; set; }
        public double lng { get; set; }
        public string name { get; set; }
    }
    public class Individual
    {
        public InNeighbor[] In { get; set; }
        public int[] Out { get; set; }
        public double lat { get; set; }
        public double lng { get; set; }
        public string name { get; set; }
        
        
        public double t = 0;
        public double status = 0;
        public int week = 0;
        public bool vaccinated = false;


    }
    public class OutNeighbor
    {
        public int id { get; set; }
    }
    public class InNeighbor
    {
        public int id { get; set; }
        public double w { get; set; }
    }
    public class Company
    {
        public string companyName { get; set; }
        public string status { get; set; }
    }
    public class Response

    {
        public bool success { get; set; }
        public int index { get; set; }
        public string message { get; set; }
        public string companyId { get; set; }
        public string color { get; set; }
        public int[] infected { get; set; }

    }
}
