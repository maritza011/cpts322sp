﻿using Firebase.Database;
using Firebase.Database.Query;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeamVaxxers
{
    public partial class Engine : Form
    {
        List<PointLatLng> _points;
        public Engine()
        {
            InitializeComponent();
            map.MapProvider = GMapProviders.GoogleMap;
            map.Zoom = 10;
            map.MaxZoom = 100;
            map.MinZoom = 1;
            _points = new List<PointLatLng>();

        }
        private async void getPopulationAsync()
        {
            var client = new FirebaseClient("https://heymotocarro-1a1d4.firebaseio.com/population/");
            var server = new FirebaseClient("https://cpts323-755b6-default-rtdb.firebaseio.com/");

            //******************** Get initial list of Prospect ***********************//

            var PopulationSet = await client
               .Child("/")//Prospect list
               .OnceSingleAsync<Population>();

            setUp(PopulationSet);
            //CheckIndividualsStatus(PopulationSet);

            // selectK(PopulationSet);
            await server
                .Child("/")
                .PutAsync(PopulationSet); // THis copies the orignail data to your data base for testing
        }
        private void selectK(Population PopulationSet)
        {
            List<double> k = new List<double>();
            foreach (var population in PopulationSet.individuals)
            {
                double sum = 0.0;
                foreach (var n in population.In)
                {
                    sum += n.w;
                }
                k.Add(sum);
            }
            k.Sort();
            k.Reverse(); // Gets sorted in desending order
            k.RemoveRange(1, k.Count - 1); // removes excess people not in top k
            string json = JsonConvert.SerializeObject(k);
            Console.WriteLine(json);
        }
        private void CheckIndividualsStatus(Population population)
        {
            int[] Inf = { 0 }; // list has been rid of people that have been vaccinated before this point also updated .status to 1
            var Infected = new List<int>(Inf);
            // Infected.Add(0);
            List<int> TrackInfected = new List<int>();
            TrackInfected.Add(0);
            while (Infected.Count != 0 || TrackInfected.Count != 0)
            {
                Thread.Sleep(1000);
                if (Infected.Count != 0)
                {
                    Console.WriteLine("2");
                    foreach (var infected in Infected)
                    {

                        // Since we already check their neigbors we can remove them from the list
                        // population.individuals[infected].week += 1;
                        foreach (var x in population.individuals[infected].Out) // .toNeigbors points at the people they can infect
                        {

                            if (population.individuals[x].status == 0 && population.individuals[x].vaccinated == false) // is susceptible
                            {
                                bool check = loopPossibleIndividualNeighbors(population.individuals[x], population);
                                if (check)
                                {
                                    Infected.Add(x);
                                    TrackInfected.Add(x); // we can add to the list to keep track of what iteration they are in to mark them as recovered
                                }
                            }
                        }
                        Infected.Remove(infected);
                        break;
                    }

                }

                if (TrackInfected.Count != 0)
                {
                    Console.WriteLine("1");
                    foreach (var infected in TrackInfected)
                    {
                        //Console.WriteLine(infected); 

                        if (population.individuals[infected].week == 5)
                        {
                            population.individuals[infected].status = 2;
                            plotPins(population.individuals[infected].lat, population.individuals[infected].lng, GMarkerGoogleType.green); // pin goes to recovered
                            TrackInfected.Remove(infected);
                            break;
                        }
                        population.individuals[infected].week += 1;
                    }

                }
            }
        }
        private bool loopPossibleIndividualNeighbors(Individual individual, Population PopulationSet)
        {
            double t = 0;

            foreach (var x in individual.In)
            {
                t = x.w * PopulationSet.individuals[x.id].status;

            }
            if (t >= individual.t)
            {
                foreach (var x in individual.In)
                {
                    if (PopulationSet.individuals[x.id].status == 1)
                    {
                        // update color of lines of each 
                        _points.Add(new PointLatLng(individual.lat, individual.lng));
                        _points.Add(new PointLatLng(PopulationSet.individuals[x.id].lat, PopulationSet.individuals[x.id].lng));
                        foreach (var points in _points)
                        {
                            plotlines(points.Lat, points.Lng, Color.Red);
                        }
                        plotPins(individual.lat, individual.lng, GMarkerGoogleType.red); // updates the person pin when infected
                        _points.Clear();
                    }
                }
                System.Threading.Thread.Sleep(500);
                foreach (var x in individual.In)
                {
                    if (PopulationSet.individuals[x.id].status == 1)
                    {
                        // update color of lines of each 
                        _points.Add(new PointLatLng(individual.lat, individual.lng));
                        _points.Add(new PointLatLng(PopulationSet.individuals[x.id].lat, PopulationSet.individuals[x.id].lng));
                        foreach (var points in _points)
                        {
                            plotlines(points.Lat, points.Lng, Color.Black);
                        }
                        plotPins(individual.lat, individual.lng, GMarkerGoogleType.red); // updates the person pin when infected
                        _points.Clear();
                    }

                }

                individual.status = 1;
                return true;

            }
            return false;
        }
        private void setUp(Population PopulationSet) // need to add the initial infected
        {
            foreach (var population in PopulationSet.individuals)
            {
                foreach (var n in population.In)
                {
                    _points.Add(new PointLatLng(population.lat, population.lng));
                    _points.Add(new PointLatLng(PopulationSet.individuals[n.id].lat, PopulationSet.individuals[n.id].lng));
                    foreach (var points in _points)
                    {
                        plotPins(points.Lat, points.Lng, GMarkerGoogleType.lightblue);
                        plotlines(points.Lat, points.Lng, Color.Black);
                    }
                    _points.Clear();
                }
            }
        }
        private void plotPins(double lat, double lng, GMarkerGoogleType markerColor)
        {
            PointLatLng point = new PointLatLng(lat, lng);
            GMapMarker marker = new GMarkerGoogle(point, markerColor);
            GMapOverlay markers = new GMapOverlay();
            markers.Markers.Add(marker);
            map.Overlays.Add(markers);
            map.Position = new PointLatLng(2.134, -2.345);
            map.Zoom = 6;
        }
        private void plotlines(double lat, double lng, Color line)
        {
            var poly = new GMapPolygon(_points, "MyArea")
            {
                Stroke = new Pen(line, 2)
            };
            GMapOverlay polygons = new GMapOverlay("polygons");
            polygons.Polygons.Add(poly);
            map.Overlays.Add(polygons);
            map.Position = new PointLatLng(2.134, -2.345);
            map.Zoom = 6;
        }

        async Task getAccessAsync()
        {
            HttpClient httpclient = new HttpClient();
            string selectedkey = null, responseString, companyId;
            FormUrlEncodedContent content;
            HttpResponseMessage response;
            var company = new Company
            {
                companyName = "Vaxxers",
                status = "active"
            };
            var dictionary = new Dictionary<string, string>
            {
                { "companyName",company.companyName  },
                { "status",company.status}
            };

            content = new FormUrlEncodedContent(dictionary);
            response = await httpclient.PostAsync("https://us-central1-cpts323battle.cloudfunctions.net/reportCompany", content);
            responseString = await response.Content.ReadAsStringAsync();
            Response data = Newtonsoft.Json.JsonConvert.DeserializeObject<Response>(responseString);
            //Response message
            Console.WriteLine(data.message);
            Console.WriteLine(data.companyId);
            companyId = data.companyId;


            dictionary = new Dictionary<string, string>
            {
                { "K", "12345" },
                { "companyId", companyId} // we do need to change this 
            };
            content = new FormUrlEncodedContent(dictionary);
            response = await httpclient.PostAsync("https://us-central1-cpts323battle.cloudfunctions.net/sendK", content);
            responseString = await response.Content.ReadAsStringAsync();
            data = Newtonsoft.Json.JsonConvert.DeserializeObject<Response>(responseString);
            Console.WriteLine(data.message);
            var stop = Console.ReadLine();
        }

        private void loadBtn_Click_1(object sender, EventArgs e)
        {
            getPopulationAsync();
            //getAccessAsync();
            //call huristic 
            //getAccess();
            //sendKAsync();
            //plot points on map and start graph 
            //user will see points then hit start
        }
    }
}
